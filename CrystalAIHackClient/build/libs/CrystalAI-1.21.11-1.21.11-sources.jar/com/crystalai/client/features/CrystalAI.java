package com.crystalai.client.features;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import net.minecraft.class_1268;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import com.crystalai.client.utils.AICore;

public class CrystalAI {
    private final class_310 mc = class_310.method_1551();
    private boolean enabled = true;
    private class_1657 target;
    private int actionCooldown;
    private int comboCount;
    private boolean isAggressive;
    private int switchCooldown;
    private int placeDelay;
    private int breakDelay;
    private final Queue<class_243> predictedPositions = new LinkedList<>();
    private final Map<class_2338, Long> placedCrystals = new HashMap<>();
    private boolean wTapEnabled = true;
    private boolean sTapEnabled = true;
    private int wTapCooldown;
    private int sTapCooldown;

    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;
        if (actionCooldown > 0)
            actionCooldown--;
        if (switchCooldown > 0)
            switchCooldown--;
        if (placeDelay > 0)
            placeDelay--;
        if (breakDelay > 0)
            breakDelay--;
        if (wTapCooldown > 0)
            wTapCooldown--;
        if (sTapCooldown > 0)
            sTapCooldown--;

        float health = mc.field_1724.method_6032() + mc.field_1724.method_6067();
        target = findBestTarget();

        updatePredictedPositions();
        cleanupOldCrystals();

        if (health <= 8.0f) {
            activateDefensiveMode();
            return;
        }

        if (target != null && target.method_5805()) {
            double distance = mc.field_1724.method_5739(target);
            isAggressive = health > 15.0f && distance < 8.0f;

            if (isAggressive) {
                performAggressiveCombo();
            } else {
                performTacticalCombat();
            }
        } else {
            resetCombatState();
        }

        manageHotbar();
        manageArmor();
    }

    private void updatePredictedPositions() {
        if (target != null && target.method_5805()) {
            class_243 currentPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            class_243 velocity = target.method_18798();

            for (int i = 1; i <= 5; i++) {
                class_243 predicted = currentPos.method_1019(velocity.method_1021(i * 0.1));
                predictedPositions.offer(predicted);
                if (predictedPositions.size() > 10)
                    predictedPositions.poll();
            }
        }
    }

    private void cleanupOldCrystals() {
        long currentTime = System.currentTimeMillis();
        placedCrystals.entrySet().removeIf(
                entry -> currentTime - entry.getValue() > 5000 || mc.field_1687.method_8320(entry.getKey()).method_26215());
    }

    private void activateDefensiveMode() {
        ensureTotemInOffhand();
        eatGapIfPossible();

        if (target != null && mc.field_1724.method_5739(target) < 4.0f) {
            performEmergencyEscape();
        }
    }

    private void performAggressiveCombo() {
        if (wTapEnabled && wTapCooldown == 0) {
            performWTap();
            wTapCooldown = 10;
        }

        if (sTapEnabled && sTapCooldown == 0) {
            performSTap();
            sTapCooldown = 8;
        }

        doAdvancedCrystalCombat();
        performSprintReset();
    }

    private void performTacticalCombat() {
        if (mc.field_1724.method_5739(target) > 6.0f && actionCooldown == 0) {
            performSmartPearl();
            actionCooldown = 25;
        }

        doAdvancedCrystalCombat();
        maintainOptimalDistance();
    }

    private void performWTap() {
        if (!mc.field_1724.method_5624())
            return;
        mc.field_1690.field_1867.method_23481(false);
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
        mc.field_1690.field_1867.method_23481(true);
    }

    private void performSTap() {
        if (!mc.field_1724.method_5624())
            return;
        mc.field_1690.field_1881.method_23481(true);
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
        mc.field_1690.field_1881.method_23481(false);
    }

    private void performSprintReset() {
        if (mc.field_1724.method_5624() && actionCooldown == 0) {
            mc.field_1690.field_1867.method_23481(false);
            actionCooldown = 3;
            mc.field_1690.field_1867.method_23481(true);
        }
    }

    private void doAdvancedCrystalCombat() {
        class_1511 bestCrystal = findBestCrystalToBreak();
        if (bestCrystal != null && breakDelay == 0) {
            double predictedDamage = AICore.calculateDamage(
                    new class_243(bestCrystal.method_23317(), bestCrystal.method_23318(), bestCrystal.method_23321()), target);

            if (predictedDamage >= 5.0 || comboCount >= 2) {
                breakCrystal(bestCrystal);
                breakDelay = 4;
                comboCount++;
            }
        }

        class_2338 bestPlace = findBestCrystalPlacement();
        if (bestPlace != null && placeDelay == 0) {
            placeCrystal(bestPlace);
            placeDelay = 6;
            placedCrystals.put(bestPlace, System.currentTimeMillis());
        }

        ensureObsidianPlacement();
    }

    private class_1511 findBestCrystalToBreak() {
        class_243 playerPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        return mc.field_1687.method_8390(class_1511.class,
                class_238.method_30048(playerPos, 12, 12, 12),
                c -> mc.field_1724.method_5739(c) <= 6.0f).stream()
                .max(Comparator
                        .comparingDouble(c -> AICore.calculateDamage(new class_243(c.method_23317(), c.method_23318(), c.method_23321()), target)))
                .orElse(null);
    }

    private class_2338 findBestCrystalPlacement() {
        class_2338 playerPos = mc.field_1724.method_24515();
        class_2338 targetPos = target.method_24515();

        class_2338 bestPos = null;
        double maxScore = 0;

        for (int x = -2; x <= 2; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -2; z <= 2; z++) {
                    class_2338 pos = targetPos.method_10069(x, y, z);
                    if (!canPlaceCrystal(pos))
                        continue;

                    double damage = AICore.calculateDamage(class_243.method_24953(pos), target);
                    double selfDamage = AICore.calculateDamage(class_243.method_24953(pos), mc.field_1724);
                    double distance = pos.method_10262(playerPos);

                    double score = damage - (selfDamage * 0.5) - (distance * 0.1);
                    if (isPredictedHit(pos))
                        score += 2.0;

                    if (score > maxScore) {
                        maxScore = score;
                        bestPos = pos;
                    }
                }
            }
        }
        return bestPos;
    }

    private boolean isPredictedHit(class_2338 pos) {
        class_243 crystalPos = class_243.method_24953(pos);
        return predictedPositions.stream()
                .anyMatch(pred -> pred.method_1022(crystalPos) < 1.5);
    }

    private void breakCrystal(class_1511 crystal) {
        AICore.rotate(new class_243(crystal.method_23317(), crystal.method_23318(), crystal.method_23321()));
        mc.field_1761.method_2918(mc.field_1724, crystal);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void placeCrystal(class_2338 pos) {
        if (!switchToItem(class_1802.field_8301))
            return;
        AICore.rotate(class_243.method_24953(pos).method_1031(0, 0.5, 0));
        class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private boolean canPlaceCrystal(class_2338 pos) {
        if (!mc.field_1687.method_8320(pos).method_27852(class_2246.field_10540) &&
                !mc.field_1687.method_8320(pos).method_27852(class_2246.field_9987))
            return false;
        return mc.field_1687.method_22347(pos.method_10084()) && mc.field_1687.method_22347(pos.method_10086(2)) &&
                mc.field_1687.method_8335(null, new class_238(pos.method_10084())).isEmpty() &&
                !placedCrystals.containsKey(pos);
    }

    private void ensureObsidianPlacement() {
        class_2338 targetFeet = target.method_24515().method_10074();
        if (!mc.field_1687.method_8320(targetFeet).method_27852(class_2246.field_10540) &&
                !mc.field_1687.method_8320(targetFeet).method_27852(class_2246.field_9987)) {
            placeObsidian(targetFeet);
        }
    }

    private void placeObsidian(class_2338 pos) {
        if (!switchToItem(class_1802.field_8281))
            return;
        AICore.rotate(class_243.method_24953(pos));
        class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void performSmartPearl() {
        if (!switchToItem(class_1802.field_8634))
            return;
        class_243 bestPosition = calculateBestPearlPosition();
        AICore.rotate(bestPosition);
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private class_243 calculateBestPearlPosition() {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 velocity = target.method_18798();
        double distance = mc.field_1724.method_5739(target);

        class_243 predicted = targetPos.method_1019(velocity.method_1021(distance * 0.15));
        class_243 playerPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        return predicted.method_1019(predicted.method_1020(playerPos).method_1029().method_1021(3));
    }

    private void maintainOptimalDistance() {
        double distance = mc.field_1724.method_5739(target);
        if (distance > 5.0f) {
            mc.field_1690.field_1894.method_23481(true);
        } else if (distance < 3.0f) {
            mc.field_1690.field_1881.method_23481(true);
        }
    }

    private void performEmergencyEscape() {
        if (!switchToItem(class_1802.field_8634))
            return;
        mc.field_1724.method_36456(mc.field_1724.method_36454() + 180);
        mc.field_1724.method_36457(-10);
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        mc.field_1724.method_6104(class_1268.field_5808);
        actionCooldown = 20;
    }

    private void resetCombatState() {
        comboCount = 0;
        predictedPositions.clear();
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
    }

    private class_1657 findBestTarget() {
        return mc.field_1687.method_18456().stream()
                .filter(p -> p != mc.field_1724 && p.method_5805() && !p.method_7325())
                .filter(p -> mc.field_1724.method_5739(p) <= 20.0f)
                .max(Comparator.comparingDouble(p -> {
                    double distance = mc.field_1724.method_5739(p);
                    double health = p.method_6032() + p.method_6067();
                    return (100.0 - health) - (distance * 2);
                })).orElse(null);
    }

    private boolean switchToItem(net.minecraft.class_1792 item) {
        if (switchCooldown > 0)
            return false;
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item)) {
                mc.field_1724.method_31548().method_61496(i);
                switchCooldown = 2;
                return true;
            }
        }
        return false;
    }

    private void manageHotbar() {
        if (!mc.field_1724.method_6047().method_31574(class_1802.field_8301) &&
                !mc.field_1724.method_6047().method_31574(class_1802.field_8281)) {
            if (mc.field_1724.method_31548().method_18861(class_1802.field_8301) > 0) {
                switchToItem(class_1802.field_8301);
            } else if (mc.field_1724.method_31548().method_18861(class_1802.field_8281) > 0) {
                switchToItem(class_1802.field_8281);
            }
        }
    }

    private void manageArmor() {
        // Auto-armor disabled due to API changes in 1.21.11
    }

    private void ensureTotemInOffhand() {
        if (mc.field_1724.method_6079().method_31574(class_1802.field_8288))
            return;
        for (int i = 0; i < 45; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8288)) {
                int slot = i < 9 ? i + 36 : i;
                mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7790,
                        mc.field_1724);
                mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 45, 0, class_1713.field_7790,
                        mc.field_1724);
                mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7790,
                        mc.field_1724);
                return;
            }
        }
    }

    private void eatGapIfPossible() {
        if (switchToItem(class_1802.field_8367) || switchToItem(class_1802.field_8463)) {
            mc.field_1690.field_1904.method_23481(true);
        }
    }

    public void onDisable() {
        resetCombatState();
        mc.field_1690.field_1904.method_23481(false);
        mc.field_1690.field_1867.method_23481(false);
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
    }

    public void toggle() {
        enabled = !enabled;
        if (!enabled) {
            onDisable();
        }
    }

    public boolean isEnabled() {
        return enabled;
    }
}
