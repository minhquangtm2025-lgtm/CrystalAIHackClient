package com.crystalai.client.utils;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AICore {
    private static final class_310 mc = class_310.method_1551();
    private static float[] serverRotation = new float[] { 0, 0 };
    private static boolean rotationSmooth = true;
    private static final float[] previousRotation = new float[] { 0, 0 };

    public static double calculateDamage(class_243 crystalPos, class_1657 entity) {
        if (entity == null || mc.field_1687 == null)
            return 0;
        class_243 entityPos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        double distance = entityPos.method_1022(crystalPos);

        if (distance > 12.0)
            return 0;
        if (isBlocked(crystalPos, entityPos))
            return 0;

        double impact = (1.0 - (distance / 12.0));
        double exposure = calculateExposure(crystalPos, entity);
        double damage = ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0) * exposure;

        if (entity.method_6067() > 0) {
            damage = Math.max(0, damage - entity.method_6067() * 0.5);
        }

        return damage;
    }

    private static boolean isBlocked(class_243 from, class_243 to) {
        if (mc.field_1687 == null)
            return false;
        class_3959 context = new class_3959(
                from, to,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724);
        class_239 result = mc.field_1687.method_17742(context);
        return result.method_17783() == class_239.class_240.field_1332;
    }

    private static double calculateExposure(class_243 explosionPos, class_1297 entity) {
        if (mc.field_1687 == null)
            return 0;
        class_238 box = entity.method_5829();
        double exposure = 0;
        class_243[] directions = {
                new class_243(1, 0, 0), new class_243(-1, 0, 0),
                new class_243(0, 1, 0), new class_243(0, -1, 0),
                new class_243(0, 0, 1), new class_243(0, 0, -1)
        };

        for (class_243 dir : directions) {
            class_243 testPos = explosionPos.method_1019(dir.method_1021(0.5));
            if (!isRayBlocked(explosionPos, testPos)) {
                exposure += 1.0 / 6.0;
            }
        }
        return Math.min(1.0, exposure);
    }

    private static boolean isRayBlocked(class_243 from, class_243 to) {
        if (mc.field_1687 == null)
            return true;
        class_3959 context = new class_3959(
                from, to,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724);
        class_239 result = mc.field_1687.method_17742(context);
        return result.method_17783() == class_239.class_240.field_1332;
    }

    public static void rotate(class_243 pos) {
        if (mc.field_1724 == null)
            return;

        double dx = pos.field_1352 - mc.field_1724.method_23317();
        double dy = pos.field_1351 - mc.field_1724.method_23320();
        double dz = pos.field_1350 - mc.field_1724.method_23321();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        if (rotationSmooth) {
            smoothRotate(yaw, pitch);
        } else {
            mc.field_1724.method_36456(yaw);
            mc.field_1724.method_36457(pitch);
        }

        serverRotation[0] = yaw;
        serverRotation[1] = pitch;
    }

    private static void smoothRotate(float targetYaw, float targetPitch) {
        float yawDiff = targetYaw - previousRotation[0];
        float pitchDiff = targetPitch - previousRotation[1];

        yawDiff = normalizeAngle(yawDiff);
        pitchDiff = normalizeAngle(pitchDiff);

        float speed = 15.0f;
        float newYaw = previousRotation[0] + yawDiff * (speed / 180.0f);
        float newPitch = previousRotation[1] + pitchDiff * (speed / 180.0f);

        mc.field_1724.method_36456(newYaw);
        mc.field_1724.method_36457(newPitch);

        previousRotation[0] = newYaw;
        previousRotation[1] = newPitch;
    }

    private static float normalizeAngle(float angle) {
        while (angle <= -180)
            angle += 360;
        while (angle > 180)
            angle -= 360;
        return angle;
    }

    public static float[] getServerRotation() {
        return serverRotation;
    }

    public static void setRotationSmooth(boolean smooth) {
        rotationSmooth = smooth;
    }

    public static boolean canSee(class_243 from, class_243 to) {
        if (mc.field_1687 == null)
            return false;
        class_3959 context = new class_3959(
                from, to,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724);
        class_239 result = mc.field_1687.method_17742(context);
        return result.method_17783() != class_239.class_240.field_1332;
    }

    public static boolean isPlaceable(class_2338 pos) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return false;

        if (!mc.field_1687.method_8320(pos).method_27852(class_2246.field_10540) &&
                !mc.field_1687.method_8320(pos).method_27852(class_2246.field_9987) &&
                !mc.field_1687.method_8320(pos).method_26215()) {
            return false;
        }

        class_2338 up = pos.method_10084();
        if (!mc.field_1687.method_22347(up) && !mc.field_1687.method_8320(up).method_45474()) {
            return false;
        }

        class_2338 up2 = pos.method_10086(2);
        if (!mc.field_1687.method_22347(up2) && !mc.field_1687.method_8320(up2).method_45474()) {
            return false;
        }

        return !mc.field_1687.method_8335(null, new class_238(up)).isEmpty();
    }

    public static class_2338 getPlacePosition(class_2338 targetPos) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return null;

        class_2338[] positions = {
                targetPos.method_10095(), targetPos.method_10072(), targetPos.method_10078(), targetPos.method_10067(),
                targetPos.method_10084().method_10095(), targetPos.method_10084().method_10072(), targetPos.method_10084().method_10078(), targetPos.method_10084().method_10067(),
                targetPos.method_10074()
        };

        class_2338 bestPos = null;
        double bestScore = -1;

        for (class_2338 pos : positions) {
            if (isPlaceable(pos)) {
                double distance = mc.field_1724.method_24515().method_10262(pos);
                double score = 1000 - distance;
                if (score > bestScore) {
                    bestScore = score;
                    bestPos = pos;
                }
            }
        }

        return bestPos;
    }

    public static class_2350 getPlaceSide(class_2338 pos) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return class_2350.field_11036;

        class_2350[] sides = { class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039 };

        for (class_2350 side : sides) {
            class_2338 neighbor = pos.method_10093(side);
            if (!mc.field_1687.method_8320(neighbor).method_26215()) {
                return side.method_10153();
            }
        }

        return class_2350.field_11036;
    }

    public static class_3965 getHitResult(class_2338 pos) {
        class_2350 side = getPlaceSide(pos);
        class_243 hitPos = class_243.method_24953(pos).method_1019(class_243.method_24954(side.method_62675()).method_1021(0.5));
        return new class_3965(hitPos, side, pos, false);
    }

    public static int getArmorValue(class_1799 stack) {
        if (stack.method_7960())
            return 0;
        return 0; // Simplified for 1.21.11 compatibility
    }

    public static double getSpeed(class_1657 entity) {
        if (entity == null)
            return 0;
        class_243 velocity = entity.method_18798();
        return Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);
    }

    public static class_243 predictPosition(class_1297 entity, int ticks) {
        if (entity == null)
            return class_243.field_1353;
        class_243 pos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        class_243 velocity = entity.method_18798();

        return pos.method_1019(velocity.method_1021(ticks * 0.1));
    }

    public static boolean isMoving(class_1297 entity) {
        if (entity == null)
            return false;
        class_243 velocity = entity.method_18798();
        return Math.abs(velocity.field_1352) > 0.01 || Math.abs(velocity.field_1350) > 0.01;
    }

    public static double getDistanceToEntity(class_1297 entity1, class_1297 entity2) {
        if (entity1 == null || entity2 == null)
            return Double.MAX_VALUE;
        class_243 pos1 = new class_243(entity1.method_23317(), entity1.method_23318(), entity1.method_23321());
        class_243 pos2 = new class_243(entity2.method_23317(), entity2.method_23318(), entity2.method_23321());
        return pos1.method_1022(pos2);
    }

    public static boolean isInAttackRange(class_1297 target) {
        if (mc.field_1724 == null || target == null)
            return false;
        return mc.field_1724.method_5739(target) <= 6.0;
    }

    public static boolean canReach(class_2338 pos) {
        if (mc.field_1724 == null)
            return false;
        double distance = mc.field_1724.method_24515().method_10262(pos);
        return distance <= 36.0; // 6 blocks squared
    }

    public static float getHealth(class_1657 entity) {
        if (entity == null)
            return 0;
        return entity.method_6032() + entity.method_6067();
    }

    public static boolean isLowHealth(class_1657 entity) {
        return getHealth(entity) < 10.0f;
    }

    public static boolean isCriticalHit(class_1657 player) {
        if (player == null || mc.field_1687 == null)
            return false;
        return !player.method_24828() &&
                player.method_18798().field_1351 < 0 &&
                !mc.field_1687.method_8320(player.method_24515().method_10074()).method_26215();
    }

    public static void resetRotation() {
        serverRotation[0] = mc.field_1724 != null ? mc.field_1724.method_36454() : 0;
        serverRotation[1] = mc.field_1724 != null ? mc.field_1724.method_36455() : 0;
        previousRotation[0] = serverRotation[0];
        previousRotation[1] = serverRotation[1];
    }

    public static boolean hasLineOfSight(class_243 from, class_243 to) {
        if (mc.field_1687 == null)
            return false;
        class_3959 context = new class_3959(
                from, to,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724);
        class_239 result = mc.field_1687.method_17742(context);
        return result.method_17783() == class_239.class_240.field_1333;
    }

    public static class_243 getBestAttackPosition(class_1297 target) {
        if (target == null || mc.field_1724 == null)
            return class_243.field_1353;
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 playerPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

        class_243 direction = targetPos.method_1020(playerPos).method_1029();
        return targetPos.method_1020(direction.method_1021(2.5));
    }

    public static boolean isSafeToPlaceCrystal(class_2338 pos) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return false;

        class_243 crystalPos = class_243.method_24953(pos);
        double selfDamage = calculateDamage(crystalPos, mc.field_1724);
        return selfDamage < 4.0;
    }

    public static class_2338 findBestObsidianPlace(class_2338 targetPos) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return null;

        class_2338[] positions = {
                targetPos.method_10074(), targetPos.method_10095(), targetPos.method_10072(),
                targetPos.method_10078(), targetPos.method_10067()
        };

        for (class_2338 pos : positions) {
            if (mc.field_1687.method_8320(pos).method_26215() ||
                    mc.field_1687.method_8320(pos).method_45474()) {
                return pos;
            }
        }

        return null;
    }

    public static double calculateComboPotential(class_1297 target) {
        if (target == null || !(target instanceof class_1657))
            return 0;
        class_1657 player = (class_1657) target;

        double health = getHealth(player);
        double speed = getSpeed(player);
        boolean moving = isMoving(target);
        boolean lowHealth = isLowHealth(player);

        double potential = 0;
        potential += (100 - health) * 0.5;
        potential += speed * 10;
        potential += moving ? 20 : 0;
        potential += lowHealth ? 30 : 0;

        return potential;
    }

    public static boolean shouldSwitchTarget(class_1297 currentTarget, class_1297 newTarget) {
        if (currentTarget == null)
            return true;
        if (newTarget == null)
            return false;

        double currentPotential = calculateComboPotential(currentTarget);
        double newPotential = calculateComboPotential(newTarget);

        double currentDist = mc.field_1724.method_5739(currentTarget);
        double newDist = mc.field_1724.method_5739(newTarget);

        return newPotential > currentPotential + 10 && newDist < currentDist + 2;
    }
}
