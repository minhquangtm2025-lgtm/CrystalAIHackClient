package com.crystalai.client;

import com.crystalai.client.features.CrystalAI;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class CrystalAIClient implements ClientModInitializer {

    private final CrystalAI crystalAI = new CrystalAI();
    private class_304 toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.crystalai.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                class_304.class_11900.field_62556));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                crystalAI.toggle();
            }

            if (crystalAI.isEnabled() && client.field_1724 != null) {
                crystalAI.onTick();
            }
        });
    }
}
